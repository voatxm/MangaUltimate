echo "Started..."
python "main.py"
